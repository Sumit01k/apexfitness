"use client";

import { Mic, Clock } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useApexFitStore } from "@/lib/store";

function Waveform({ active }: { active: boolean }) {
  const bars = 5;
  return (
    <div className="flex h-4 items-center gap-0.5">
      {Array.from({ length: bars }).map((_, i) => (
        <span
          key={i}
          className={`w-0.5 rounded-full bg-signal ${active ? "animate-waveform" : "h-1 opacity-30"}`}
          style={{
            height: active ? "100%" : "4px",
            animationDelay: `${i * 0.12}s`,
          }}
        />
      ))}
    </div>
  );
}

export function MacroBar() {
  const isVoiceListening = useApexFitStore((s) => s.isVoiceListening);
  const setVoiceListening = useApexFitStore((s) => s.setVoiceListening);
  const macros = useApexFitStore((s) => s.macros);
  const circadianWindowMinutesLeft = useApexFitStore((s) => s.circadianWindowMinutesLeft);

  return (
    <footer className="flex h-20 shrink-0 items-center gap-6 border-t border-surface-border bg-surface/60 px-6 backdrop-blur">
      {/* Voice command indicator */}
      <button
        onClick={() => setVoiceListening(!isVoiceListening)}
        className="flex shrink-0 items-center gap-2 rounded-md border border-surface-border bg-surface-raised px-3 py-2 transition-colors hover:border-signal/40"
      >
        <Mic className={`h-4 w-4 ${isVoiceListening ? "text-signal" : "text-ink-faint"}`} />
        <Waveform active={isVoiceListening} />
        <span className="font-mono text-xs text-ink-muted">
          {isVoiceListening ? "Listening…" : "Voice off"}
        </span>
      </button>

      {/* Macro meters */}
      <div className="flex flex-1 items-center gap-6 overflow-x-auto">
        {macros.map((macro) => (
          <div key={macro.label} className="min-w-[140px] flex-1">
            <div className="mb-1 flex items-center justify-between">
              <span className="text-xs text-ink-muted">{macro.label}</span>
              <span className="font-mono text-xs text-ink">
                {macro.currentG}g <span className="text-ink-faint">/ {macro.targetG}g</span>
              </span>
            </div>
            <Progress
              value={(macro.currentG / macro.targetG) * 100}
              indicatorClassName={macro.colorClass}
            />
          </div>
        ))}
      </div>

      {/* Circadian alert */}
      <div className="flex shrink-0 items-center gap-2 rounded-md border border-ember/30 bg-ember/10 px-3 py-2">
        <Clock className="h-4 w-4 text-ember" />
        <div className="leading-tight">
          <div className="font-mono text-xs font-semibold text-ember">
            {circadianWindowMinutesLeft}m left
          </div>
          <div className="text-[10px] text-ink-muted">Peak Metabolic Window</div>
        </div>
      </div>
    </footer>
  );
}
