"use client";

import { useEffect, useState } from "react";
import { Video, VideoOff, Bot, User } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useApexFitStore } from "@/lib/store";
import type { PoseKeypoint } from "@/types/dashboard";

/**
 * Simulated skeleton — a stand-in for live @tensorflow-models/pose-detection
 * output. In production this list is replaced by keypoints read each frame
 * from a `poseDetection.createDetector(SupportedModels.MoveNet)` instance
 * running against the <video> element's stream (see /lib/pose.ts wiring).
 */
const BASE_KEYPOINTS: Omit<PoseKeypoint, "confidence">[] = [
  { id: "nose", x: 0.5, y: 0.18 },
  { id: "l_shoulder", x: 0.38, y: 0.32 },
  { id: "r_shoulder", x: 0.62, y: 0.32 },
  { id: "l_elbow", x: 0.32, y: 0.48 },
  { id: "r_elbow", x: 0.68, y: 0.48 },
  { id: "l_hip", x: 0.42, y: 0.58 },
  { id: "r_hip", x: 0.58, y: 0.58 },
  { id: "l_knee", x: 0.4, y: 0.76 },
  { id: "r_knee", x: 0.6, y: 0.76 },
  { id: "l_ankle", x: 0.4, y: 0.94 },
  { id: "r_ankle", x: 0.6, y: 0.94 },
];

const SKELETON_EDGES: [string, string][] = [
  ["l_shoulder", "r_shoulder"],
  ["l_shoulder", "l_elbow"],
  ["r_shoulder", "r_elbow"],
  ["l_shoulder", "l_hip"],
  ["r_shoulder", "r_hip"],
  ["l_hip", "r_hip"],
  ["l_hip", "l_knee"],
  ["r_hip", "r_knee"],
  ["l_knee", "l_ankle"],
  ["r_knee", "r_ankle"],
];

function useSimulatedPose(active: boolean) {
  const [keypoints, setKeypoints] = useState<PoseKeypoint[]>(
    BASE_KEYPOINTS.map((k) => ({ ...k, confidence: 0.95 }))
  );

  useEffect(() => {
    if (!active) return;
    const interval = setInterval(() => {
      setKeypoints(
        BASE_KEYPOINTS.map((k) => ({
          ...k,
          x: k.x + (Math.random() - 0.5) * 0.015,
          y: k.y + (Math.random() - 0.5) * 0.01,
          confidence: 0.85 + Math.random() * 0.15,
        }))
      );
    }, 400);
    return () => clearInterval(interval);
  }, [active]);

  return keypoints;
}

export function AICoachHUD() {
  const isCameraLive = useApexFitStore((s) => s.isCameraLive);
  const setCameraLive = useApexFitStore((s) => s.setCameraLive);
  const formQualityPercent = useApexFitStore((s) => s.formQualityPercent);
  const fps = useApexFitStore((s) => s.fps);
  const transcript = useApexFitStore((s) => s.coachTranscript);

  const keypoints = useSimulatedPose(isCameraLive);
  const byId = Object.fromEntries(keypoints.map((k) => [k.id, k]));

  return (
    <Card className="flex h-full flex-col">
      <CardHeader>
        <CardTitle>AI Coach</CardTitle>
        <Button variant="ghost" size="icon" onClick={() => setCameraLive(!isCameraLive)}>
          {isCameraLive ? <Video className="h-4 w-4 text-signal" /> : <VideoOff className="h-4 w-4 text-ink-faint" />}
        </Button>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-4">
        {/* Simulated AR feed */}
        <div className="hud-frame relative aspect-[4/3] w-full overflow-hidden rounded-md border border-surface-border bg-[#070B0C]">
          {isCameraLive ? (
            <>
              <div className="absolute inset-0 bg-gradient-to-b from-signal/5 via-transparent to-transparent" />
              <div className="absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-signal/10 to-transparent animate-scan" />
              <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                {SKELETON_EDGES.map(([a, b], i) => {
                  const p1 = byId[a];
                  const p2 = byId[b];
                  if (!p1 || !p2) return null;
                  return (
                    <line
                      key={i}
                      x1={p1.x * 100}
                      y1={p1.y * 100}
                      x2={p2.x * 100}
                      y2={p2.y * 100}
                      stroke="#00E5A0"
                      strokeOpacity={0.6}
                      strokeWidth={0.6}
                    />
                  );
                })}
                {keypoints.map((k) => (
                  <circle
                    key={k.id}
                    cx={k.x * 100}
                    cy={k.y * 100}
                    r={1.1}
                    fill="#00E5A0"
                    opacity={k.confidence}
                  />
                ))}
              </svg>
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                <Badge>{fps} FPS</Badge>
                <Badge variant={formQualityPercent >= 85 ? "default" : "ember"}>
                  Form: {formQualityPercent}%
                </Badge>
              </div>
            </>
          ) : (
            <div className="flex h-full items-center justify-center text-xs text-ink-faint">
              Camera paused
            </div>
          )}
        </div>

        {/* Chat transcript */}
        <div className="flex-1 space-y-2 overflow-y-auto">
          {transcript.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-2 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-surface-raised">
                {msg.role === "coach" ? (
                  <Bot className="h-3 w-3 text-signal" />
                ) : (
                  <User className="h-3 w-3 text-ink-muted" />
                )}
              </div>
              <div
                className={`max-w-[85%] rounded-lg px-3 py-1.5 text-xs ${
                  msg.role === "coach"
                    ? "bg-surface-raised text-ink"
                    : "bg-signal/10 text-ink"
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
