"use client";

import { Activity, Flame } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useApexFitStore } from "@/lib/store";

export function Header() {
  const recovery = useApexFitStore((s) => s.recovery);

  const recoveryTone =
    recovery.recoveryPercent >= 70
      ? "text-signal"
      : recovery.recoveryPercent >= 40
      ? "text-ember"
      : "text-vital";

  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-surface-border bg-surface/60 px-6 backdrop-blur">
      {/* Branding */}
      <div className="flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-signal/10">
          <Activity className="h-4 w-4 text-signal" strokeWidth={2.5} />
        </div>
        <span className="font-display text-lg font-bold tracking-tight text-ink">
          Apex<span className="text-signal">Fit</span>
        </span>
      </div>

      {/* Live HRV / Recovery + Profile */}
      <div className="flex items-center gap-4">
        <div className="hidden items-center gap-2 rounded-md border border-surface-border bg-surface-raised px-3 py-1.5 sm:flex">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-signal opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-signal" />
          </span>
          <span className="font-mono text-xs text-ink-muted">HRV</span>
          <span className={`font-mono text-sm font-semibold ${recoveryTone}`}>
            {recovery.recoveryPercent}% Recovered
          </span>
        </div>

        <Badge variant="ember" className="gap-1">
          <Flame className="h-3 w-3" />
          {recovery.streakDays} Day Streak
        </Badge>

        <Avatar className="border border-surface-border">
          <AvatarImage src="/avatar-placeholder.png" alt="Profile" />
          <AvatarFallback>SM</AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
