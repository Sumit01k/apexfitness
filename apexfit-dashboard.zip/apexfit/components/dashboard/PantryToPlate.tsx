"use client";

import { ShoppingCart, Sparkles, Loader2 } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { useApexFitStore } from "@/lib/store";

export function PantryToPlate() {
  const pantryItems = useApexFitStore((s) => s.pantryItems);
  const togglePantryItem = useApexFitStore((s) => s.togglePantryItem);
  const recipe = useApexFitStore((s) => s.generatedRecipe);
  const isGenerating = useApexFitStore((s) => s.isGeneratingRecipe);
  const generateRecipe = useApexFitStore((s) => s.generateRecipe);

  return (
    <Card className="flex h-full flex-col">
      <CardHeader>
        <CardTitle>Pantry to Plate</CardTitle>
        <Sparkles className="h-4 w-4 text-signal" />
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-5">
        {/* Ingredient selector */}
        <div>
          <p className="mb-2 text-xs font-medium text-ink-muted">What&apos;s in your kitchen?</p>
          <ul className="space-y-2">
            {pantryItems.map((item) => (
              <li key={item.id}>
                <label className="flex cursor-pointer items-center gap-3 rounded-md border border-surface-border bg-surface-raised/50 px-3 py-2 transition-colors hover:border-signal/40">
                  <Checkbox
                    checked={item.selected}
                    onCheckedChange={() => togglePantryItem(item.id)}
                  />
                  <span className="flex-1 text-sm text-ink">{item.name}</span>
                  <span className="font-mono text-[11px] text-ink-faint">
                    {item.proteinPer100g}g P / 100g
                  </span>
                </label>
              </li>
            ))}
          </ul>
        </div>

        <Button
          size="sm"
          className="w-full"
          onClick={() => generateRecipe()}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Matching macros…
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" /> Generate Recipe
            </>
          )}
        </Button>

        {/* Generated recipe card */}
        {recipe && (
          <div className="rounded-lg border border-signal/20 bg-signal/5 p-4">
            <p className="font-display text-sm font-semibold text-ink">{recipe.title}</p>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="font-mono text-2xl font-bold text-signal">{recipe.kcal}</span>
              <span className="text-xs text-ink-muted">kcal</span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 font-mono text-xs">
              <div className="rounded-sm bg-surface-raised px-2 py-1 text-center">
                <div className="text-ink-muted">Protein</div>
                <div className="font-semibold text-ink">{recipe.proteinG}g</div>
              </div>
              <div className="rounded-sm bg-surface-raised px-2 py-1 text-center">
                <div className="text-ink-muted">Carbs</div>
                <div className="font-semibold text-ink">{recipe.carbsG}g</div>
              </div>
              <div className="rounded-sm bg-surface-raised px-2 py-1 text-center">
                <div className="text-ink-muted">Fat</div>
                <div className="font-semibold text-ink">{recipe.fatG}g</div>
              </div>
            </div>
            <ol className="mt-3 space-y-1 text-xs text-ink-muted">
              {recipe.steps.map((step, i) => (
                <li key={i}>
                  <span className="font-mono text-signal">{i + 1}.</span> {step}
                </li>
              ))}
            </ol>
          </div>
        )}

        {/* Quick-commerce CTA */}
        <Button variant="ember" size="sm" className="mt-auto w-full">
          <ShoppingCart className="h-4 w-4" />
          Order Ingredients via Blinkit / Zepto
        </Button>
      </CardContent>
    </Card>
  );
}
