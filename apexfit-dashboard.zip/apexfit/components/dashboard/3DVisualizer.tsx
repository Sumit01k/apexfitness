"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Environment } from "@react-three/drei";
import * as THREE from "three";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { useApexFitStore } from "@/lib/store";
import type { MuscleGroupActivation } from "@/types/dashboard";

/**
 * Heatmap color ramp: cool graphite (inactive) -> signal teal (moderate)
 * -> ember (peak activation). Mirrors the HRV/recovery color language
 * used in the header so "hot" always means "high" across the app.
 */
function activationColor(intensity: number) {
  const cool = new THREE.Color("#1E2A2C");
  const mid = new THREE.Color("#00E5A0");
  const hot = new THREE.Color("#FF7A45");
  if (intensity < 0.6) return cool.lerp(mid, intensity / 0.6);
  return mid.lerp(hot, (intensity - 0.6) / 0.4);
}

function MuscleBlock({
  activation,
  position,
  size,
  massGainKg,
}: {
  activation: MuscleGroupActivation;
  position: [number, number, number];
  size: [number, number, number];
  massGainKg: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const color = useMemo(() => activationColor(activation.intensity), [activation.intensity]);
  // Projected mass gain subtly scales high-activation (trained) groups more than others —
  // a lightweight visual stand-in for hypertrophy projection.
  const growth = 1 + (massGainKg / 10) * 0.25 * activation.intensity;

  useFrame((state) => {
    if (!meshRef.current) return;
    const pulse = 1 + Math.sin(state.clock.elapsedTime * 1.5) * 0.01 * activation.intensity;
    meshRef.current.scale.set(growth * pulse, growth * pulse, growth * pulse);
  });

  return (
    <mesh ref={meshRef} position={position} castShadow receiveShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial color={color} roughness={0.4} metalness={0.1} emissive={color} emissiveIntensity={0.15} />
    </mesh>
  );
}

function Avatar({ massGainKg }: { massGainKg: number }) {
  const activation = useApexFitStore((s) => s.muscleActivation);
  const find = (g: MuscleGroupActivation["group"]) =>
    activation.find((a) => a.group === g) ?? { group: g, intensity: 0.1 };

  return (
    <group position={[0, -0.2, 0]}>
      {/* Head */}
      <mesh position={[0, 1.55, 0]}>
        <sphereGeometry args={[0.22, 24, 24]} />
        <meshStandardMaterial color="#2A3436" />
      </mesh>
      {/* Torso: chest / back */}
      <MuscleBlock activation={find("chest")} position={[0, 1.05, 0]} size={[0.5, 0.6, 0.28]} massGainKg={massGainKg} />
      {/* Shoulders */}
      <MuscleBlock activation={find("shoulders")} position={[-0.34, 1.3, 0]} size={[0.18, 0.18, 0.2]} massGainKg={massGainKg} />
      <MuscleBlock activation={find("shoulders")} position={[0.34, 1.3, 0]} size={[0.18, 0.18, 0.2]} massGainKg={massGainKg} />
      {/* Arms */}
      <MuscleBlock activation={find("arms")} position={[-0.42, 0.85, 0]} size={[0.16, 0.5, 0.16]} massGainKg={massGainKg} />
      <MuscleBlock activation={find("arms")} position={[0.42, 0.85, 0]} size={[0.16, 0.5, 0.16]} massGainKg={massGainKg} />
      {/* Core */}
      <MuscleBlock activation={find("core")} position={[0, 0.65, 0]} size={[0.4, 0.35, 0.24]} massGainKg={massGainKg} />
      {/* Glutes */}
      <MuscleBlock activation={find("glutes")} position={[0, 0.35, -0.05]} size={[0.42, 0.22, 0.24]} massGainKg={massGainKg} />
      {/* Quads */}
      <MuscleBlock activation={find("quads")} position={[-0.15, -0.05, 0.02]} size={[0.2, 0.55, 0.22]} massGainKg={massGainKg} />
      <MuscleBlock activation={find("quads")} position={[0.15, -0.05, 0.02]} size={[0.2, 0.55, 0.22]} massGainKg={massGainKg} />
      {/* Hamstrings (behind quads) */}
      <MuscleBlock activation={find("hamstrings")} position={[-0.15, -0.05, -0.1]} size={[0.18, 0.5, 0.14]} massGainKg={massGainKg} />
      <MuscleBlock activation={find("hamstrings")} position={[0.15, -0.05, -0.1]} size={[0.18, 0.5, 0.14]} massGainKg={massGainKg} />
      {/* Calves */}
      <MuscleBlock activation={find("calves")} position={[-0.15, -0.65, 0]} size={[0.16, 0.4, 0.18]} massGainKg={massGainKg} />
      <MuscleBlock activation={find("calves")} position={[0.15, -0.65, 0]} size={[0.16, 0.4, 0.18]} massGainKg={massGainKg} />
    </group>
  );
}

export function Visualizer3D() {
  const projectedMassGainKg = useApexFitStore((s) => s.projectedMassGainKg);
  const setProjectedMassGainKg = useApexFitStore((s) => s.setProjectedMassGainKg);

  return (
    <Card className="flex h-full flex-col">
      <CardHeader>
        <CardTitle>Muscle Activation Heatmap</CardTitle>
        <div className="flex items-center gap-1.5 font-mono text-[11px] text-ink-muted">
          <span className="h-2 w-2 rounded-full bg-ember" /> Quads &amp; Glutes: peak load
        </div>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-3">
        <div className="hud-frame relative min-h-[280px] flex-1 overflow-hidden rounded-md border border-surface-border bg-[#070B0C]">
          <Canvas shadows camera={{ position: [1.6, 1.1, 2.2], fov: 40 }}>
            <ambientLight intensity={0.5} />
            <directionalLight position={[3, 4, 2]} intensity={1.1} castShadow />
            <Avatar massGainKg={projectedMassGainKg} />
            <OrbitControls
              enablePan={false}
              minDistance={1.5}
              maxDistance={4}
              target={[0, 0.6, 0]}
            />
            <Environment preset="city" />
          </Canvas>
        </div>

        {/* Future Mass Projection slider */}
        <div className="rounded-md border border-surface-border bg-surface-raised/50 p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-ink-muted">Future Mass Projection</span>
            <span className="font-mono text-sm font-semibold text-signal">
              +{projectedMassGainKg}kg Muscle Gain
            </span>
          </div>
          <Slider
            value={[projectedMassGainKg]}
            onValueChange={([v]) => setProjectedMassGainKg(v)}
            min={0}
            max={10}
            step={0.5}
          />
          <div className="mt-1 flex justify-between font-mono text-[10px] text-ink-faint">
            <span>+0kg</span>
            <span>+10kg</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
