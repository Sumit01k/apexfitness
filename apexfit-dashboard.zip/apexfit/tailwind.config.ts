import type { Config } from "tailwindcss";

/**
 * ApexFit design tokens.
 * Direction: "instrument panel" — a biometric HUD, not a generic dark dashboard.
 * Base is cool graphite (not pure black). Data reads in mono. Two accents only:
 * a bioluminescent teal for live/positive signal, and a warm ember for
 * time-pressure / alerts (circadian window, low recovery).
 */
const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#0A0E0E",
        surface: {
          DEFAULT: "#12181A",
          raised: "#1A2224",
          border: "#243032",
        },
        signal: {
          DEFAULT: "#00E5A0",
          dim: "#0A5C48",
          foreground: "#04140F",
        },
        ember: {
          DEFAULT: "#FF7A45",
          dim: "#5C3420",
        },
        vital: {
          DEFAULT: "#FF4D6D",
        },
        ink: {
          DEFAULT: "#E7EDED",
          muted: "#8AA0A0",
          faint: "#4C6060",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      borderRadius: {
        lg: "0.75rem",
        md: "0.5rem",
        sm: "0.25rem",
      },
      keyframes: {
        scan: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
        pulseDot: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" },
        },
        waveform: {
          "0%, 100%": { transform: "scaleY(0.3)" },
          "50%": { transform: "scaleY(1)" },
        },
      },
      animation: {
        scan: "scan 3.2s linear infinite",
        pulseDot: "pulseDot 1.6s ease-in-out infinite",
        waveform: "waveform 0.9s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
