import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

const keypointSchema = z.object({
  id: z.string(),
  x: z.number().min(0).max(1),
  y: z.number().min(0).max(1),
  confidence: z.number().min(0).max(1),
});

const poseLogSchema = z.object({
  sessionId: z.string(),
  keypoints: z.array(keypointSchema),
  formQualityPct: z.number().min(0).max(100),
  fps: z.number().min(0).max(240),
});

/**
 * POST /api/workouts/pose-log
 * Body: { sessionId, keypoints, formQualityPct, fps }
 *
 * Called ~2-4x/sec by the client while @tensorflow-models/pose-detection
 * runs against the live camera feed. In production this writes a PoseLog
 * row (see prisma/schema.prisma) and may trigger a coaching message when
 * form quality drops below threshold.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = poseLogSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { sessionId, formQualityPct, fps } = parsed.data;

  let coachFeedback: string | null = null;
  if (formQualityPct < 75) {
    coachFeedback = "Form dipped below target — slow the tempo and reset your brace.";
  } else if (formQualityPct >= 95) {
    coachFeedback = "Excellent rep. Keep that exact bar path.";
  }

  // TODO(prod): prisma.poseLog.create({ data: { sessionId, keypoints, formQualityPct, fps, coachFeedback } })

  return NextResponse.json({
    ok: true,
    sessionId,
    receivedAt: new Date().toISOString(),
    fps,
    coachFeedback,
  });
}

/**
 * GET /api/workouts/pose-log?sessionId=...
 * Returns a mock recent-history stub — replace with a Prisma findMany
 * scoped to the session, ordered by capturedAt desc, limited to N.
 */
export async function GET(req: NextRequest) {
  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ error: "sessionId is required" }, { status: 400 });
  }

  return NextResponse.json({
    sessionId,
    logs: [
      { capturedAt: new Date(Date.now() - 4000).toISOString(), formQualityPct: 92, fps: 60 },
      { capturedAt: new Date(Date.now() - 2000).toISOString(), formQualityPct: 94, fps: 60 },
    ],
  });
}
