import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import type { GeneratedRecipe } from "@/types/dashboard";

const requestSchema = z.object({
  ingredientIds: z.array(z.string()).min(1, "Select at least one ingredient"),
});

// Static nutrition table — stand-in for a Prisma PantryItem lookup by userId.
const INGREDIENT_LIBRARY: Record<
  string,
  { name: string; proteinPer100g: number; kcalPer100g: number }
> = {
  eggs: { name: "Eggs", proteinPer100g: 13, kcalPer100g: 155 },
  spinach: { name: "Spinach", proteinPer100g: 2.9, kcalPer100g: 23 },
  oats: { name: "Oats", proteinPer100g: 13.5, kcalPer100g: 389 },
  chicken: { name: "Chicken Breast", proteinPer100g: 31, kcalPer100g: 165 },
};

/**
 * POST /api/recipes/generate
 * Body: { ingredientIds: string[] }
 *
 * Mock "macro-matched" generator: in production this would call an LLM
 * (or a retrieval + constraint-solver pipeline) seeded with the user's
 * macro targets and selected pantry items. Here it deterministically
 * composes a recipe so the UI has a real contract to build against.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = requestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { ingredientIds } = parsed.data;
  const known = ingredientIds.filter((id) => id in INGREDIENT_LIBRARY);

  if (known.length === 0) {
    return NextResponse.json(
      { error: "No recognized ingredients supplied" },
      { status: 422 }
    );
  }

  // Naive macro composition per 150g portion of each selected ingredient.
  const portionG = 150;
  let kcal = 0;
  let proteinG = 0;
  for (const id of known) {
    const item = INGREDIENT_LIBRARY[id];
    kcal += (item.kcalPer100g * portionG) / 100;
    proteinG += (item.proteinPer100g * portionG) / 100;
  }

  const names = known.map((id) => INGREDIENT_LIBRARY[id].name);
  const title = `Macro-Matched ${proteinG > 30 ? "High-Protein" : "Balanced"} ${
    names.includes("Eggs") ? "Omelet" : "Bowl"
  }`;

  const recipe: GeneratedRecipe = {
    id: crypto.randomUUID(),
    title,
    kcal: Math.round(kcal),
    proteinG: Math.round(proteinG),
    carbsG: Math.round(kcal * 0.15) / 4, // rough placeholder split
    fatG: Math.round(kcal * 0.35) / 9,
    usedIngredients: known,
    steps: [
      `Prep ${names.join(", ")} — wash, dice, and portion to ${portionG}g each.`,
      "Cook aromatics and any protein sources first over medium-high heat.",
      "Fold in remaining ingredients and season to taste.",
      "Plate and log the meal to update today's macro bar.",
    ],
  };

  return NextResponse.json(recipe);
}
