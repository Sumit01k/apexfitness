export interface PantryItem {
  id: string;
  name: string;
  selected: boolean;
  proteinPer100g: number;
  kcalPer100g: number;
}

export interface GeneratedRecipe {
  id: string;
  title: string;
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  usedIngredients: string[];
  steps: string[];
}

export interface MacroTarget {
  label: "Protein" | "Carbs" | "Fat";
  currentG: number;
  targetG: number;
  colorClass: string;
}

export interface PoseKeypoint {
  id: string;
  x: number; // 0-1 normalized
  y: number; // 0-1 normalized
  confidence: number;
}

export interface CoachMessage {
  id: string;
  role: "coach" | "user";
  text: string;
  timestamp: number;
}

export interface MuscleGroupActivation {
  group: "quads" | "glutes" | "hamstrings" | "calves" | "core" | "back" | "chest" | "shoulders" | "arms";
  intensity: number; // 0-1, drives heatmap color
}

export interface RecoveryStatus {
  hrvScore: number; // 0-100
  recoveryPercent: number;
  streakDays: number;
}
